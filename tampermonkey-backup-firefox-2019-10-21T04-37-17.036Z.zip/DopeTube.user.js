// ==UserScript==
// @name        DopeTube
// @namespace   https://matrix.to/#/!kvIhLfjTKZnUjdCvdp:arcrealityinc.com?via=arcrealityinc.com
// @description Redirect YouTube watch pages to HookTube which uses raw suggestions from YouTube's related videos API prior to the application of Google's filter which gives preference to monetized videos. Embedded YouTube player links are sent to Invidio.us making use of it's device native player & backend which deoes not contain YouTube tracking scripts.
// @include     *youtube*
// @include     *hooktube*
// @include     *invidio*
// @version     2.0.1
// @require  https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js
// @grant    GM_addStyle
// @run-at document-start
// @updateURL    https://www.arcrealityinc.com/git/DopeTube/DopeTube.user.js
// @downloadURL  https://www.arcrealityinc.com/git/DopeTube/DopeTube.user.js
// ==/UserScript==

// Variables for use throughout the script
var input=document.createElement("input");
var redirectToInvidious = false;
var isInvidioSearchPage = false;
var url = window.location.toString();

//Checking if link resolves is a page we want to use Invidious for (watch page, playlists, channels).
if (url.indexOf('/watch?v=') !== - 1){
    if (url.indexOf('invidio.us') !== - 1) {
        window.location = url.replace(/invidio.us/, 'hooktube.com');
    }
    // Redirecting from YouTube's censorship and spying page.
    if (url.indexOf('youtube.com') !== - 1) {
        window.location = url.replace(/youtube.com/, 'hooktube.com');
    }

}
